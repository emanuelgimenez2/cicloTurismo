import { Suspense } from "react"
import Navbar from "@/components/navbar"
import HeroCarousel from "@/components/hero-carousel"
import InscriptionSection from "@/components/inscription-section"
import JerseySection from "@/components/jersey-section"
import BenefitsSection from "@/components/benefits-section"
import GallerySection from "@/components/gallery-section"
import SponsorsSection from "@/components/sponsors-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import SectionTitle from "@/components/section-title"
import {
  getEventConfig,
  getCarouselImages,
  getOfficialJersey,
  getBenefits,
  getGalleryImages,
  getSponsors,
  getContactInfo,
  getSocialNetworks,
} from "@/lib/actions"
import { seedInitialData } from "@/lib/seed-data"
import { createServerSupabaseClient } from "@/lib/supabase"

export default async function Home() {
  // Insertar datos iniciales si es necesario
  await seedInitialData()

  // Obtener datos del evento
  const eventConfig = await getEventConfig()
  const carouselImages = await getCarouselImages()
  const officialJersey = await getOfficialJersey()
  const benefits = await getBenefits()
  const galleryImages = await getGalleryImages()
  const sponsors = await getSponsors()
  const contactInfo = await getContactInfo()
  const socialNetworks = await getSocialNetworks()

  // Obtener el número de inscripciones
  const supabase = createServerSupabaseClient()
  const { count: registrationCount } = await supabase
    .from("registrations")
    .select("*", { count: "exact", head: true })
    .eq("edition", eventConfig?.current_edition || 2)

  return (
    <main className="min-h-screen">
      <Navbar />

      {/* Hero con carrusel */}
      <HeroCarousel images={carouselImages} />

      {/* Sección de inscripción */}
      <section id="inscripcion" className="py-16">
        <div className="container mx-auto px-4">
          <SectionTitle
            title="Inscripción"
            subtitle="Participa en el evento de cicloturismo más importante de la región"
          />

          <Suspense fallback={<div>Cargando información...</div>}>
            <InscriptionSection eventConfig={eventConfig} registrationCount={registrationCount || 0} />
          </Suspense>
        </div>
      </section>

      {/* Sección de remera oficial */}
      <JerseySection jersey={officialJersey} />

      {/* Sección de beneficios */}
      <BenefitsSection benefits={benefits} />

      {/* Sección de galería */}
      <GallerySection images={galleryImages} />

      {/* Sección de sponsors */}
      <SponsorsSection sponsors={sponsors} />

      {/* Sección de contacto */}
      <ContactSection contactInfo={contactInfo} socialNetworks={socialNetworks} />

      {/* Footer */}
      <Footer />
    </main>
  )
}
