import { Suspense } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import RegistrationForm from "@/components/registration-form"
import { getEventConfig } from "@/lib/actions"
import { createServerSupabaseClient } from "@/lib/supabase"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default async function InscripcionPage() {
  // Obtener configuración del evento
  const eventConfig = await getEventConfig()

  // Obtener el número de inscripciones
  const supabase = createServerSupabaseClient()
  const { count: registrationCount } = await supabase
    .from("registrations")
    .select("*", { count: "exact", head: true })
    .eq("edition", eventConfig?.current_edition || 2)

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="pt-24 pb-16 bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-blue-500/10">
        <div className="container mx-auto px-4">
          <Link href="/#inscripcion">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="mr-2 h-4 w-4" /> Volver
            </Button>
          </Link>

          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Formulario de Inscripción
          </h1>
          <p className="text-gray-600 mb-8">
            Completa el siguiente formulario para inscribirte al evento Cicloturismo Termal de Federación.
          </p>

          <Suspense fallback={<div>Cargando formulario...</div>}>
            {eventConfig ? (
              <RegistrationForm eventConfig={eventConfig} registrationCount={registrationCount || 0} />
            ) : (
              <div className="text-center text-gray-600">No se pudo cargar la información del evento.</div>
            )}
          </Suspense>
        </div>
      </div>

      <Footer />
    </main>
  )
}
