import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import GallerySection from "@/components/gallery-section"
import { getGalleryImages } from "@/lib/actions"
import { seedInitialData } from "@/lib/seed-data"

export default async function GaleriaPage() {
  // Insertar datos iniciales si es necesario
  await seedInitialData()

  // Obtener todas las imágenes de la galería
  const galleryImages = await getGalleryImages()

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="pt-24">
        <GallerySection images={galleryImages} showAll={true} />
      </div>

      <Footer />
    </main>
  )
}
