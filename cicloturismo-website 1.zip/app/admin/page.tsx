"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Edit, Settings, FileSpreadsheet, ImageIcon, Award, Building, UserPlus } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"

export default function AdminPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [adminEmail, setAdminEmail] = useState("")
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  useEffect(() => {
    async function checkAuth() {
      try {
        const { data: sessionData } = await supabase.auth.getSession()

        if (!sessionData.session) {
          router.push("/admin/login")
          return
        }

        setAdminEmail(sessionData.session.user.email || "")
        setIsLoading(false)
      } catch (error) {
        console.error("Error al verificar autenticación:", error)
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [supabase, router])

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut()
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente",
      })
      router.push("/admin/login")
    } catch (error) {
      console.error("Error al cerrar sesión:", error)
      toast({
        title: "Error",
        description: "No se pudo cerrar la sesión",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-purple-500 border-r-transparent"></div>
          <p className="mt-4 text-gray-600">Cargando panel de administración...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Panel de Administración
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">
              Conectado como: <span className="font-medium">{adminEmail}</span>
            </span>
            <Link href="/" target="_blank">
              <Button variant="outline" size="sm">
                Ver sitio
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={handleSignOut}>
              Cerrar sesión
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-bold mb-2">Bienvenido al Panel de Administración</h2>
          <p className="text-gray-600">
            Desde aquí podrás gestionar todos los aspectos del evento Cicloturismo Termal de Federación.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-purple-500" />
                Inscripciones
              </CardTitle>
              <CardDescription>Gestiona las inscripciones del evento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Link href="/admin/inscripciones">
                  <Button className="w-full">Ver inscripciones</Button>
                </Link>
                <Link href="/admin/inscripciones/exportar">
                  <Button variant="outline" className="w-full">
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Exportar a Excel
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Edit className="h-5 w-5 text-purple-500" />
                Contenido del sitio
              </CardTitle>
              <CardDescription>Edita el contenido de las secciones del sitio</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Link href="/admin/contenido/carrusel">
                  <Button variant="outline" className="w-full">
                    <ImageIcon className="h-4 w-4 mr-2" />
                    Carrusel de imágenes
                  </Button>
                </Link>
                <Link href="/admin/contenido/remera">
                  <Button variant="outline" className="w-full">
                    <Award className="h-4 w-4 mr-2" />
                    Remera oficial
                  </Button>
                </Link>
                <Link href="/admin/contenido/sponsors">
                  <Button variant="outline" className="w-full">
                    <Building className="h-4 w-4 mr-2" />
                    Sponsors
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-purple-500" />
                Configuración
              </CardTitle>
              <CardDescription>Configura los parámetros generales del evento</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Link href="/admin/configuracion">
                  <Button className="w-full">Configurar evento</Button>
                </Link>
                <Link href="/admin/configuracion/nueva-edicion">
                  <Button variant="outline" className="w-full">
                    Nueva edición
                  </Button>
                </Link>
                <Link href="/admin/add-admin">
                  <Button variant="outline" className="w-full">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Añadir administrador
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
