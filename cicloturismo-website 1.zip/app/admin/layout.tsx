"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { createClientSupabaseClient } from "@/lib/supabase"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true)
  const pathname = usePathname()
  const router = useRouter()
  const supabase = createClientSupabaseClient()

  const isLoginPage = pathname === "/admin/login"
  const isSetupPage = pathname === "/admin/setup"

  useEffect(() => {
    async function checkAuth() {
      if (isLoginPage || isSetupPage) {
        setIsLoading(false)
        return
      }

      try {
        // Verificar si el usuario está autenticado
        const { data: sessionData } = await supabase.auth.getSession()

        if (!sessionData.session) {
          router.push("/admin/login")
          return
        }

        // Verificar si es administrador
        const { data: adminData } = await supabase
          .from("admins")
          .select("*")
          .eq("email", sessionData.session.user.email)
          .single()

        if (!adminData) {
          await supabase.auth.signOut()
          router.push("/admin/login")
          return
        }

        setIsLoading(false)
      } catch (error) {
        console.error("Error al verificar autenticación:", error)
        router.push("/admin/login")
      }
    }

    checkAuth()
  }, [supabase, router, isLoginPage, isSetupPage])

  if (isLoading && !isLoginPage && !isSetupPage) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-purple-500 border-r-transparent"></div>
          <p className="mt-4 text-gray-600">Verificando autenticación...</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
