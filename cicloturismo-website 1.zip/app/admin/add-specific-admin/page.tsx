"use client"

import { useState, useEffect } from "react"
import { addAdminUser } from "@/lib/admin-actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import Link from "next/link"

export default function AddSpecificAdminPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [result, setResult] = useState<any>(null)

  const email = "cicloturismotermal@federacion.com"
  const password = "CicloTermal"

  useEffect(() => {
    async function addAdmin() {
      try {
        setIsLoading(true)
        const response = await addAdminUser(email, password)
        setResult(response)
      } catch (error) {
        console.error("Error al añadir administrador:", error)
        setResult({
          success: false,
          message: "Error inesperado al añadir administrador",
        })
      } finally {
        setIsLoading(false)
      }
    }

    addAdmin()
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Añadir Administrador
          </CardTitle>
          <CardDescription>Añadiendo usuario administrador específico</CardDescription>
        </CardHeader>

        <CardContent>
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
              <p className="mt-4 text-gray-600">Procesando solicitud...</p>
            </div>
          ) : result?.success ? (
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-green-800 mb-2">Operación exitosa</h3>
                  <p className="text-green-700 mb-4">{result.message}</p>
                  <div className="bg-white p-4 rounded border border-green-200">
                    <p className="mb-1">
                      <span className="font-medium">Email:</span> {email}
                    </p>
                    <p>
                      <span className="font-medium">Contraseña:</span> {password}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-red-800 mb-2">Error</h3>
                  <p className="text-red-700">{result?.message || "Error al añadir administrador"}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex justify-center">
          <Link href="/admin/login">
            <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white">
              Ir a la página de inicio de sesión
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
