"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { createClientSupabaseClient } from "@/lib/supabase"
import { useToast } from "@/components/ui/use-toast"

export default function AdminSetupPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [adminCreated, setAdminCreated] = useState(false)
  const [adminEmail, setAdminEmail] = useState("admin@cicloturismo.com")
  const [adminPassword, setAdminPassword] = useState("admin123456")
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  useEffect(() => {
    async function createAdmin() {
      setIsLoading(true)
      try {
        // Verificar si ya existe un administrador
        const { data: existingAdmins, error: adminsError } = await supabase.from("admins").select("id").limit(1)

        if (adminsError) {
          console.error("Error al verificar administradores:", adminsError)
          toast({
            title: "Error",
            description: "No se pudo verificar si ya existe un administrador",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        if (existingAdmins && existingAdmins.length > 0) {
          setAdminCreated(true)
          setIsLoading(false)
          return
        }

        // Crear usuario en Supabase Auth
        const { data: authUser, error: authError } = await supabase.auth.signUp({
          email: adminEmail,
          password: adminPassword,
        })

        if (authError) {
          console.error("Error al crear usuario:", authError)
          toast({
            title: "Error",
            description: "No se pudo crear el usuario administrador",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        // Insertar en la tabla de administradores
        const { error: insertError } = await supabase.from("admins").insert({
          email: adminEmail,
        })

        if (insertError) {
          console.error("Error al insertar administrador:", insertError)
          toast({
            title: "Error",
            description: "No se pudo registrar el usuario como administrador",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }

        setAdminCreated(true)
        toast({
          title: "Éxito",
          description: "Usuario administrador creado correctamente",
        })
      } catch (error) {
        console.error("Error inesperado:", error)
        toast({
          title: "Error",
          description: "Ocurrió un error inesperado",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    createAdmin()
  }, [supabase, toast])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-md">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            Configuración de Administrador
          </h1>
          <p className="text-gray-600 mt-2">Credenciales para acceder al panel de administración</p>
        </div>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-purple-500 border-r-transparent"></div>
            <p className="mt-4 text-gray-600">Configurando administrador...</p>
          </div>
        ) : adminCreated ? (
          <div className="space-y-6">
            <div className="bg-green-50 p-4 rounded-lg">
              <h2 className="font-semibold text-green-800 mb-2">Administrador configurado correctamente</h2>
              <p className="text-green-700 mb-4">
                Ya puedes iniciar sesión en el panel de administración con las siguientes credenciales:
              </p>
              <div className="bg-white p-4 rounded border border-green-200">
                <p className="mb-1">
                  <span className="font-medium">Email:</span> {adminEmail}
                </p>
                <p>
                  <span className="font-medium">Contraseña:</span> {adminPassword}
                </p>
              </div>
            </div>

            <div className="text-center">
              <Link href="/admin/login">
                <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white">
                  Ir al inicio de sesión
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center text-red-600">
            <p>Ocurrió un error al configurar el administrador.</p>
            <Button className="mt-4 bg-gray-200 text-gray-800" onClick={() => window.location.reload()}>
              Intentar nuevamente
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
