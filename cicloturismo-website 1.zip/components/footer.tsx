import Link from "next/link"
import { getSocialNetworks } from "@/lib/actions"
import { Facebook, Instagram, Twitter, Mail, Phone } from "lucide-react"

export default async function Footer() {
  const socialNetworks = await getSocialNetworks()

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case "facebook":
        return <Facebook className="h-5 w-5" />
      case "instagram":
        return <Instagram className="h-5 w-5" />
      case "twitter":
        return <Twitter className="h-5 w-5" />
      case "mail":
        return <Mail className="h-5 w-5" />
      case "phone":
        return <Phone className="h-5 w-5" />
      default:
        return <Instagram className="h-5 w-5" />
    }
  }

  return (
    <footer className="bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-blue-500/10">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
              Cicloturismo Termal
            </h3>
            <p className="text-gray-600 mb-4">
              Evento de cicloturismo a realizarse el 12 de octubre de 2025 en Federación, Entre Ríos, Argentina.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Enlaces rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/#inscripcion" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Inscripción
                </Link>
              </li>
              <li>
                <Link href="/#remera" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Remera Oficial
                </Link>
              </li>
              <li>
                <Link href="/#beneficios" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Beneficios
                </Link>
              </li>
              <li>
                <Link href="/#galeria" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Galería
                </Link>
              </li>
              <li>
                <Link href="/galeria" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Ver todas las fotos
                </Link>
              </li>
              <li>
                <Link href="/#sponsors" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Sponsors
                </Link>
              </li>
              <li>
                <Link href="/#contacto" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Contacto
                </Link>
              </li>
              <li>
                <Link href="/admin/login" className="text-gray-600 hover:text-purple-600 transition-colors">
                  Administración
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Síguenos</h3>
            <div className="flex space-x-4">
              {socialNetworks.map((social) => (
                <Link
                  key={social.id}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white p-2 rounded-full shadow-md hover:shadow-lg transition-shadow"
                >
                  {getIconComponent(social.icon)}
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-6 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} Cicloturismo Termal de Federación. Todos los derechos reservados.</p>
          <p className="mt-2">
            <Link href="/admin/login" className="hover:text-purple-600 transition-colors">
              Acceso administradores
            </Link>
          </p>
        </div>
      </div>
    </footer>
  )
}
