"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { createRegistration } from "@/lib/actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { EventConfig } from "@/lib/types"

interface RegistrationFormProps {
  eventConfig: EventConfig
  registrationCount: number
}

const formSchema = z.object({
  first_name: z.string().min(2, "El nombre es requerido"),
  last_name: z.string().min(2, "El apellido es requerido"),
  dni: z.string().min(7, "El DNI debe tener al menos 7 caracteres"),
  birth_date: z.string().min(1, "La fecha de nacimiento es requerida"),
  city: z.string().min(2, "La localidad es requerida"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(8, "El teléfono debe tener al menos 8 caracteres"),
  gender: z.string().min(1, "El género es requerido"),
  shirt_size: z.string().min(1, "El talle de remera es requerido"),
  health_conditions: z.string().optional(),
  physical_consent: z.boolean().refine((val) => val === true, {
    message: "Debes aceptar la declaración de aptitud física",
  }),
  payment_proof: z.any().optional(),
})

type FormValues = z.infer<typeof formSchema>

export default function RegistrationForm({ eventConfig, registrationCount }: RegistrationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      first_name: "",
      last_name: "",
      dni: "",
      birth_date: "",
      city: "",
      email: "",
      phone: "",
      gender: "",
      shirt_size: "",
      health_conditions: "",
      physical_consent: false,
    },
  })

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true)

    try {
      const formData = new FormData()

      // Agregar todos los campos del formulario
      Object.entries(data).forEach(([key, value]) => {
        if (key !== "payment_proof") {
          formData.append(key, value.toString())
        }
      })

      // Agregar el comprobante de pago si existe
      const paymentProofFile = form.getValues("payment_proof")
      if (paymentProofFile && paymentProofFile.length > 0) {
        formData.append("payment_proof", paymentProofFile[0])
      }

      const result = await createRegistration(formData)

      if (result.success) {
        toast({
          title: "¡Inscripción exitosa!",
          description: "Tu inscripción ha sido registrada correctamente.",
          variant: "default",
        })
        form.reset()
      } else {
        toast({
          title: "Error",
          description: result.message || "Hubo un error al procesar tu inscripción.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un error al procesar tu inscripción.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Verificar si las inscripciones están cerradas o no hay cupos disponibles
  const isRegistrationClosed = !eventConfig.registration_open
  const isRegistrationFull = registrationCount >= eventConfig.registration_limit
  const remainingSpots = eventConfig.registration_limit - registrationCount

  if (isRegistrationClosed) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
        <h3 className="text-xl font-semibold text-yellow-800 mb-2">Inscripciones cerradas</h3>
        <p className="text-yellow-700">Las inscripciones para este evento se encuentran cerradas actualmente.</p>
      </div>
    )
  }

  if (isRegistrationFull) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <h3 className="text-xl font-semibold text-red-800 mb-2">Cupos agotados</h3>
        <p className="text-red-700">Lo sentimos, todos los cupos para este evento han sido ocupados.</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="mb-6 text-center">
        <h3 className="text-2xl font-bold mb-2">Formulario de Inscripción</h3>
        <p className="text-gray-600">Completa el siguiente formulario para inscribirte al evento.</p>
        <p className="text-sm mt-2 bg-blue-50 text-blue-700 p-2 rounded-md inline-block">
          Quedan <span className="font-bold">{remainingSpots}</span> cupos disponibles
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="first_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingresa tu nombre" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="last_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Apellido</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingresa tu apellido" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="dni"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>DNI</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingresa tu DNI" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="birth_date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Fecha de nacimiento</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Localidad</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingresa tu localidad" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="tu@email.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Teléfono</FormLabel>
                  <FormControl>
                    <Input placeholder="Ingresa tu teléfono" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="gender"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Género</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona tu género" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="masculino">Masculino</SelectItem>
                      <SelectItem value="femenino">Femenino</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="shirt_size"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Talle de remera</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona tu talle" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="XS">XS</SelectItem>
                      <SelectItem value="S">S</SelectItem>
                      <SelectItem value="M">M</SelectItem>
                      <SelectItem value="L">L</SelectItem>
                      <SelectItem value="XL">XL</SelectItem>
                      <SelectItem value="XXL">XXL</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="health_conditions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>¿Tenés algún problema de salud o condición que debamos conocer?</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Describe cualquier condición médica relevante"
                    className="resize-none"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="payment_proof"
            render={({ field: { value, onChange, ...fieldProps } }) => (
              <FormItem>
                <FormLabel>Comprobante de pago</FormLabel>
                <FormControl>
                  <Input
                    type="file"
                    accept=".jpg,.jpeg,.png,.pdf"
                    onChange={(e) => onChange(e.target.files)}
                    {...fieldProps}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="physical_consent"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>
                    Declaro estar en condiciones físicas para realizar el Cicloturismo Termal de 50 km. Soy plenamente
                    consciente del esfuerzo requerido y asumo total responsabilidad por mi participación.
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Enviando..." : "Completar inscripción"}
          </Button>
        </form>
      </Form>
    </div>
  )
}
