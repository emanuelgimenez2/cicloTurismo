import Image from "next/image"
import Link from "next/link"
import SectionTitle from "./section-title"
import type { Sponsor } from "@/lib/types"

interface SponsorsSectionProps {
  sponsors: Sponsor[]
}

export default function SponsorsSection({ sponsors }: SponsorsSectionProps) {
  // Si no hay sponsors, mostrar un placeholder
  if (sponsors.length === 0) {
    return (
      <section id="sponsors" className="py-16">
        <div className="container mx-auto px-4">
          <SectionTitle title="Sponsors" subtitle="Empresas que hacen posible este evento" />
          <div className="text-center text-gray-600">No hay sponsors disponibles.</div>
        </div>
      </section>
    )
  }

  return (
    <section id="sponsors" className="py-16">
      <div className="container mx-auto px-4">
        <SectionTitle title="Sponsors" subtitle="Empresas que hacen posible este evento" />
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-8 items-center">
          {sponsors.map((sponsor) => (
            <div key={sponsor.id} className="flex justify-center">
              {sponsor.website_url ? (
                <Link
                  href={sponsor.website_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="relative w-full h-24 grayscale hover:grayscale-0 transition-all duration-300"
                >
                  <Image
                    src={sponsor.logo_url || "/placeholder.svg"}
                    alt={sponsor.name}
                    fill
                    className="object-contain"
                  />
                </Link>
              ) : (
                <div className="relative w-full h-24 grayscale hover:grayscale-0 transition-all duration-300">
                  <Image
                    src={sponsor.logo_url || "/placeholder.svg"}
                    alt={sponsor.name}
                    fill
                    className="object-contain"
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
