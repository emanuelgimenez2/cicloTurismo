"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import SectionTitle from "./section-title"
import type { GalleryImage } from "@/lib/types"
import { X, ImageIcon } from "lucide-react"

interface GallerySectionProps {
  images: GalleryImage[]
  showAll?: boolean
}

export default function GallerySection({ images, showAll = false }: GallerySectionProps) {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null)

  const openLightbox = (image: GalleryImage) => {
    setSelectedImage(image)
    document.body.style.overflow = "hidden"
  }

  const closeLightbox = () => {
    setSelectedImage(null)
    document.body.style.overflow = "auto"
  }

  // Si no hay imágenes, mostrar un placeholder
  if (images.length === 0) {
    return (
      <section id="galeria" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionTitle title="Galería de Fotos" subtitle="Revive los mejores momentos del evento" />
          <div className="text-center text-gray-600">No hay imágenes disponibles en la galería.</div>
        </div>
      </section>
    )
  }

  // Determinar qué imágenes mostrar
  const displayImages = showAll ? images : images.slice(0, 5)

  return (
    <section id="galeria" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionTitle title="Galería de Fotos" subtitle="Revive los mejores momentos del evento" />

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {displayImages.map((image) => (
            <div
              key={image.id}
              className="relative aspect-square rounded-lg overflow-hidden cursor-pointer"
              onClick={() => openLightbox(image)}
            >
              <Image
                src={image.image_url || "/placeholder.svg"}
                alt={image.alt_text}
                fill
                className="object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}

          {/* Mostrar el botón "Ver todas" solo en la página principal */}
          {!showAll && images.length > 5 && (
            <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-blue-500/20 flex items-center justify-center">
              <Link href="/galeria">
                <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white">
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Ver todas las imágenes ({images.length})
                </Button>
              </Link>
            </div>
          )}
        </div>

        {/* Mostrar botón para volver a la página principal en la página de galería */}
        {showAll && (
          <div className="mt-8 text-center">
            <Link href="/#galeria">
              <Button variant="outline">Volver a la página principal</Button>
            </Link>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4" onClick={closeLightbox}>
          <button
            className="absolute top-4 right-4 text-white p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            onClick={closeLightbox}
          >
            <X size={24} />
          </button>
          <div className="relative w-full max-w-4xl max-h-[80vh] aspect-auto" onClick={(e) => e.stopPropagation()}>
            <Image
              src={selectedImage.image_url || "/placeholder.svg"}
              alt={selectedImage.alt_text}
              fill
              className="object-contain"
            />
          </div>
        </div>
      )}
    </section>
  )
}
