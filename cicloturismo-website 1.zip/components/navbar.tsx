"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const closeMenu = () => {
    setIsOpen(false)
  }

  const scrollToSection = (id: string) => {
    closeMenu()
    const element = document.getElementById(id)
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.pageYOffset
      window.scrollTo({
        top: offsetTop - 80,
        behavior: "smooth",
      })
    }
  }

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled ? "bg-white/90 backdrop-blur-md shadow-md" : "bg-transparent",
      )}
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link
            href="/"
            className="text-xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent"
          >
            Cicloturismo Termal
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/#inscripcion" className="text-gray-700 hover:text-purple-600 transition-colors">
              Inscripción
            </Link>
            <button
              onClick={() => scrollToSection("remera")}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Remera Oficial
            </button>
            <button
              onClick={() => scrollToSection("beneficios")}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Beneficios
            </button>
            <button
              onClick={() => scrollToSection("galeria")}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Galería
            </button>
            <button
              onClick={() => scrollToSection("sponsors")}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Sponsors
            </button>
            <button
              onClick={() => scrollToSection("contacto")}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Contacto
            </button>
            <Link href="/inscripcion">
              <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white">
                Inscribirme
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={toggleMenu} className="text-gray-700 hover:text-purple-600 transition-colors">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
            <Link
              href="/#inscripcion"
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
              onClick={closeMenu}
            >
              Inscripción
            </Link>
            <button
              onClick={() => scrollToSection("remera")}
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
            >
              Remera Oficial
            </button>
            <button
              onClick={() => scrollToSection("beneficios")}
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
            >
              Beneficios
            </button>
            <button
              onClick={() => scrollToSection("galeria")}
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
            >
              Galería
            </button>
            <button
              onClick={() => scrollToSection("sponsors")}
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
            >
              Sponsors
            </button>
            <button
              onClick={() => scrollToSection("contacto")}
              className="text-gray-700 hover:text-purple-600 transition-colors py-2"
            >
              Contacto
            </button>
            <Link href="/inscripcion" onClick={closeMenu}>
              <Button className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white w-full">
                Inscribirme
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}
