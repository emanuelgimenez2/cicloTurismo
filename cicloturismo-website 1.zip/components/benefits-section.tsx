import SectionTitle from "./section-title"
import type { Benefit } from "@/lib/types"
import { Award, Coffee, Droplet, Heart, ShieldCheck, Shirt, Utensils, Wrench } from "lucide-react"

interface BenefitsSectionProps {
  benefits: Benefit[]
}

export default function BenefitsSection({ benefits }: BenefitsSectionProps) {
  const getIconComponent = (iconName?: string) => {
    switch (iconName) {
      case "award":
        return <Award className="h-8 w-8 text-purple-500" />
      case "coffee":
        return <Coffee className="h-8 w-8 text-purple-500" />
      case "droplet":
        return <Droplet className="h-8 w-8 text-purple-500" />
      case "heart":
        return <Heart className="h-8 w-8 text-purple-500" />
      case "shield":
        return <ShieldCheck className="h-8 w-8 text-purple-500" />
      case "shirt":
        return <Shirt className="h-8 w-8 text-purple-500" />
      case "utensils":
        return <Utensils className="h-8 w-8 text-purple-500" />
      case "wrench":
        return <Wrench className="h-8 w-8 text-purple-500" />
      default:
        return <Award className="h-8 w-8 text-purple-500" />
    }
  }

  // Si no hay beneficios, mostrar un placeholder
  if (benefits.length === 0) {
    return (
      <section id="beneficios" className="py-16">
        <div className="container mx-auto px-4">
          <SectionTitle title="Beneficios de la Inscripción" subtitle="Conoce todo lo que incluye tu inscripción" />
          <div className="text-center text-gray-600">Información de beneficios no disponible.</div>
        </div>
      </section>
    )
  }

  return (
    <section id="beneficios" className="py-16">
      <div className="container mx-auto px-4">
        <SectionTitle title="Beneficios de la Inscripción" subtitle="Conoce todo lo que incluye tu inscripción" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit) => (
            <div key={benefit.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">{getIconComponent(benefit.icon)}</div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
