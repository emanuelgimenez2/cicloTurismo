import Image from "next/image"
import SectionTitle from "./section-title"
import type { OfficialJersey } from "@/lib/types"

interface JerseySectionProps {
  jersey: OfficialJersey | null
}

export default function JerseySection({ jersey }: JerseySectionProps) {
  // Si no hay información de la remera, mostrar un placeholder
  if (!jersey) {
    return (
      <section id="remera" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <SectionTitle title="Remera Oficial" subtitle="Conoce la remera oficial del evento" />
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative w-full max-w-md aspect-square bg-gray-200 rounded-lg">
                <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                  Imagen no disponible
                </div>
              </div>
            </div>
            <div className="w-full md:w-1/2">
              <p className="text-gray-600">Información de la remera oficial no disponible.</p>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="remera" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionTitle title="Remera Oficial" subtitle="Conoce la remera oficial del evento" />
        <div className="flex flex-col md:flex-row items-center justify-center gap-8">
          <div className="w-full md:w-1/2 flex justify-center">
            <div className="relative w-full max-w-md aspect-square rounded-lg overflow-hidden shadow-lg">
              <Image
                src={jersey.image_url || "/placeholder.svg"}
                alt="Remera oficial del evento"
                fill
                className="object-cover"
              />
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: jersey.description }} />
          </div>
        </div>
      </div>
    </section>
  )
}
