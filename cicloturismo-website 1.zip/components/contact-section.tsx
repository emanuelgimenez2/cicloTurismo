"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import SectionTitle from "./section-title"
import type { ContactInfo, SocialNetwork } from "@/lib/types"
import { Facebook, Instagram, Twitter, Mail, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

interface ContactSectionProps {
  contactInfo: ContactInfo | null
  socialNetworks: SocialNetwork[]
}

declare global {
  interface Window {
    initMap: () => void
    google: any
  }
}

export default function ContactSection({ contactInfo, socialNetworks }: ContactSectionProps) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const [map, setMap] = useState<any | null>(null)

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case "facebook":
        return <Facebook className="h-5 w-5" />
      case "instagram":
        return <Instagram className="h-5 w-5" />
      case "twitter":
        return <Twitter className="h-5 w-5" />
      case "mail":
        return <Mail className="h-5 w-5" />
      case "phone":
        return <Phone className="h-5 w-5" />
      default:
        return <Instagram className="h-5 w-5" />
    }
  }

  // Inicializar el mapa cuando el componente se monta
  useEffect(() => {
    if (!contactInfo?.show_map) return

    const initMap = () => {
      if (typeof window === "undefined" || !window.google) return

      const mapElement = document.getElementById("map")
      if (!mapElement) return

      const mapOptions = {
        center: {
          lat: contactInfo.map_latitude,
          lng: contactInfo.map_longitude,
        },
        zoom: contactInfo.map_zoom,
        mapTypeId: window.google.maps.MapTypeId.ROADMAP,
      }

      const newMap = new window.google.maps.Map(mapElement, mapOptions)
      setMap(newMap)

      // Agregar marcador
      new window.google.maps.Marker({
        position: {
          lat: contactInfo.map_latitude,
          lng: contactInfo.map_longitude,
        },
        map: newMap,
        title: "Punto de partida",
      })
    }

    // Cargar la API de Google Maps
    if (typeof window !== "undefined" && !window.google) {
      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap`
      script.async = true
      script.defer = true
      window.initMap = initMap
      document.head.appendChild(script)
    } else if (typeof window !== "undefined" && window.google) {
      initMap()
    }
  }, [contactInfo])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulación de envío de formulario
    setTimeout(() => {
      toast({
        title: "Mensaje enviado",
        description: "Gracias por contactarnos. Te responderemos a la brevedad.",
        variant: "default",
      })
      setName("")
      setEmail("")
      setMessage("")
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <section id="contacto" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionTitle title="Contacto" subtitle="¿Tenés alguna pregunta? ¡Contactanos!" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Formulario de contacto */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Envíanos un mensaje</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre
                </label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Tu nombre"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  required
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  Mensaje
                </label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tu mensaje"
                  rows={4}
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Enviando..." : "Enviar mensaje"}
              </Button>
            </form>
          </div>

          {/* Información de contacto y redes sociales */}
          <div>
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-xl font-semibold mb-4">Seguinos en redes sociales</h3>
              <div className="flex flex-wrap gap-4">
                {socialNetworks.map((social) => (
                  <Link
                    key={social.id}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 transition-colors p-3 rounded-lg"
                  >
                    {getIconComponent(social.icon)}
                    <span>{social.name}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Mapa */}
            {contactInfo?.show_map && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold mb-4">Ubicación</h3>
                <div id="map" className="w-full h-64 rounded-lg"></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
