"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { CarouselImage } from "@/lib/types"

interface HeroCarouselProps {
  images: CarouselImage[]
}

export default function HeroCarousel({ images }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)

  // Cambiar automáticamente la imagen cada 5 segundos
  useEffect(() => {
    if (images.length <= 1) return

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [images.length])

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length)
  }

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
  }

  // Si no hay imágenes, mostrar un placeholder
  if (images.length === 0) {
    return (
      <div className="relative h-screen w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500">
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4">
          <h1 className="text-4xl md:text-6xl font-bold text-center mb-6">Cicloturismo Termal de Federación</h1>
          <p className="text-xl md:text-2xl text-center mb-8">Segunda Edición - 12 de octubre de 2025</p>
          <Link href="/inscripcion">
            <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
              Inscribirme
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Imágenes del carrusel */}
      {images.map((image, index) => (
        <div
          key={image.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentIndex ? "opacity-100" : "opacity-0"
          }`}
        >
          <Image
            src={image.image_url || "/placeholder.svg"}
            alt={image.alt_text}
            fill
            priority={index === 0}
            className="object-cover"
          />
          {/* Overlay para mejorar la legibilidad del texto */}
          <div className="absolute inset-0 bg-black/30" />
        </div>
      ))}

      {/* Contenido del hero */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-4">
        <h1 className="text-4xl md:text-6xl font-bold text-center mb-6">Cicloturismo Termal de Federación</h1>
        <p className="text-xl md:text-2xl text-center mb-8">Segunda Edición - 12 de octubre de 2025</p>
        <Link href="/inscripcion">
          <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
            Inscribirme
          </Button>
        </Link>
      </div>

      {/* Controles del carrusel */}
      {images.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 p-2 rounded-full text-white hover:bg-black/50 transition-colors"
            aria-label="Imagen anterior"
          >
            <ChevronLeft size={24} />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 p-2 rounded-full text-white hover:bg-black/50 transition-colors"
            aria-label="Imagen siguiente"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      {/* Indicadores */}
      {images.length > 1 && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full ${index === currentIndex ? "bg-white" : "bg-white/50"}`}
              aria-label={`Ir a la imagen ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
