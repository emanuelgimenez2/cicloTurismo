"use server"

import { createServerSupabaseClient } from "./supabase"
import { revalidatePath } from "next/cache"

export async function addAdminUser(email: string, password: string) {
  try {
    const supabase = createServerSupabaseClient()

    // Verificar si el usuario ya existe en Auth
    const { data: existingUser } = await supabase.auth.admin.getUserByEmail(email)

    if (existingUser) {
      // El usuario ya existe, verificar si ya es administrador
      const { data: existingAdmin } = await supabase.from("admins").select("*").eq("email", email).single()

      if (existingAdmin) {
        return {
          success: true,
          message: "El usuario ya es administrador",
          isNewUser: false,
          isNewAdmin: false,
        }
      }

      // El usuario existe pero no es administrador, añadirlo a la tabla de admins
      const { error: adminError } = await supabase.from("admins").insert({ email })

      if (adminError) {
        console.error("Error al añadir usuario como administrador:", adminError)
        return {
          success: false,
          message: "Error al añadir usuario como administrador",
        }
      }

      return {
        success: true,
        message: "Usuario añadido como administrador correctamente",
        isNewUser: false,
        isNewAdmin: true,
      }
    }

    // El usuario no existe, crearlo y añadirlo como administrador
    const { data: newUser, error: userError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    })

    if (userError) {
      console.error("Error al crear usuario:", userError)
      return {
        success: false,
        message: "Error al crear usuario: " + userError.message,
      }
    }

    // Añadir el nuevo usuario a la tabla de admins
    const { error: adminError } = await supabase.from("admins").insert({ email })

    if (adminError) {
      console.error("Error al añadir usuario como administrador:", adminError)
      return {
        success: false,
        message: "Error al añadir usuario como administrador",
      }
    }

    revalidatePath("/admin")
    return {
      success: true,
      message: "Usuario creado y añadido como administrador correctamente",
      isNewUser: true,
      isNewAdmin: true,
    }
  } catch (error) {
    console.error("Error inesperado:", error)
    return {
      success: false,
      message: "Error inesperado al procesar la solicitud",
    }
  }
}
