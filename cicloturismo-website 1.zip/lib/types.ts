export interface EventConfig {
  id: string
  event_name: string
  event_date: string
  registration_limit: number
  registration_open: boolean
  current_edition: number
  created_at: string
  updated_at: string
}

export interface Registration {
  id: string
  first_name: string
  last_name: string
  dni: string
  birth_date: string
  city: string
  email: string
  phone: string
  gender: string
  shirt_size: string
  health_conditions?: string
  physical_consent: boolean
  payment_proof_url?: string
  payment_verified: boolean
  created_at: string
  updated_at: string
  edition: number
}

export interface CarouselImage {
  id: string
  image_url: string
  alt_text: string
  display_order: number
  created_at: string
}

export interface OfficialJersey {
  id: string
  image_url: string
  description: string
  created_at: string
  updated_at: string
}

export interface Benefit {
  id: string
  title: string
  description: string
  icon?: string
  display_order: number
  created_at: string
}

export interface GalleryImage {
  id: string
  image_url: string
  alt_text: string
  display_order: number
  created_at: string
}

export interface Sponsor {
  id: string
  name: string
  logo_url: string
  website_url?: string
  display_order: number
  created_at: string
}

export interface ContactInfo {
  id: string
  show_map: boolean
  map_latitude: number
  map_longitude: number
  map_zoom: number
  created_at: string
  updated_at: string
}

export interface SocialNetwork {
  id: string
  name: string
  url: string
  icon: string
  display_order: number
  created_at: string
}
