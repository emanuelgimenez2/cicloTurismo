"use server"

import { createServerSupabaseClient } from "./supabase"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import type { Registration } from "./types"

// Obtener configuración del evento
export async function getEventConfig() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("event_config")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(1)

  if (error) {
    console.error("Error al obtener la configuración del evento:", error)
    return null
  }

  // Si no hay datos, devolver una configuración por defecto
  if (!data || data.length === 0) {
    return {
      id: "default",
      event_name: "Cicloturismo Termal de Federación – Segunda Edición",
      event_date: "2025-10-12",
      registration_limit: 300,
      registration_open: true,
      current_edition: 2,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
  }

  return data[0]
}

// Obtener imágenes del carrusel
export async function getCarouselImages() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("carousel_images").select("*").order("display_order", { ascending: true })

  if (error) {
    console.error("Error al obtener las imágenes del carrusel:", error)
    return []
  }

  return data || []
}

// Obtener información de la remera oficial
export async function getOfficialJersey() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("official_jersey")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(1)

  if (error) {
    console.error("Error al obtener la información de la remera oficial:", error)
    return null
  }

  return data && data.length > 0 ? data[0] : null
}

// Obtener beneficios de inscripción
export async function getBenefits() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("benefits").select("*").order("display_order", { ascending: true })

  if (error) {
    console.error("Error al obtener los beneficios:", error)
    return []
  }

  return data || []
}

// Obtener imágenes de la galería
export async function getGalleryImages() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("gallery_images").select("*").order("display_order", { ascending: true })

  if (error) {
    console.error("Error al obtener las imágenes de la galería:", error)
    return []
  }

  return data || []
}

// Obtener sponsors
export async function getSponsors() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("sponsors").select("*").order("display_order", { ascending: true })

  if (error) {
    console.error("Error al obtener los sponsors:", error)
    return []
  }

  return data || []
}

// Obtener información de contacto
export async function getContactInfo() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("contact_info")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(1)

  if (error) {
    console.error("Error al obtener la información de contacto:", error)
    return null
  }

  return data && data.length > 0 ? data[0] : null
}

// Obtener redes sociales
export async function getSocialNetworks() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("social_networks").select("*").order("display_order", { ascending: true })

  if (error) {
    console.error("Error al obtener las redes sociales:", error)
    return []
  }

  return data || []
}

// Crear inscripción
export async function createRegistration(formData: FormData) {
  const supabase = createServerSupabaseClient()

  // Obtener configuración del evento
  const eventConfig = await getEventConfig()
  if (!eventConfig) {
    return { success: false, message: "No se pudo obtener la configuración del evento" }
  }

  // Verificar si las inscripciones están abiertas
  if (!eventConfig.registration_open) {
    return { success: false, message: "Las inscripciones están cerradas" }
  }

  // Verificar si hay cupos disponibles
  const { count } = await supabase
    .from("registrations")
    .select("*", { count: "exact", head: true })
    .eq("edition", eventConfig.current_edition)

  if (count && count >= eventConfig.registration_limit) {
    return { success: false, message: "No hay cupos disponibles" }
  }

  // Crear la inscripción
  const registration: Partial<Registration> = {
    first_name: formData.get("first_name") as string,
    last_name: formData.get("last_name") as string,
    dni: formData.get("dni") as string,
    birth_date: formData.get("birth_date") as string,
    city: formData.get("city") as string,
    email: formData.get("email") as string,
    phone: formData.get("phone") as string,
    gender: formData.get("gender") as string,
    shirt_size: formData.get("shirt_size") as string,
    health_conditions: formData.get("health_conditions") as string,
    physical_consent: formData.get("physical_consent") === "on",
    payment_verified: false,
    edition: eventConfig.current_edition,
  }

  // Procesar el comprobante de pago si existe
  const paymentProof = formData.get("payment_proof") as File
  if (paymentProof && paymentProof.size > 0) {
    const fileName = `payment_proofs/${Date.now()}_${paymentProof.name}`
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("cicloturismo")
      .upload(fileName, paymentProof)

    if (uploadError) {
      console.error("Error al subir el comprobante de pago:", uploadError)
      return { success: false, message: "Error al subir el comprobante de pago" }
    }

    const { data: urlData } = supabase.storage.from("cicloturismo").getPublicUrl(fileName)

    registration.payment_proof_url = urlData.publicUrl
  }

  // Guardar la inscripción
  const { data, error } = await supabase.from("registrations").insert(registration).select().single()

  if (error) {
    console.error("Error al crear la inscripción:", error)
    return { success: false, message: "Error al crear la inscripción" }
  }

  revalidatePath("/")
  return { success: true, message: "Inscripción creada correctamente", data }
}

// Verificar si el usuario es administrador
export async function isAdmin() {
  try {
    const supabase = createServerSupabaseClient()
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return false
    }

    const { data } = await supabase.from("admins").select("*").eq("email", session.user.email)

    return data && data.length > 0
  } catch (error) {
    console.error("Error al verificar si el usuario es administrador:", error)
    return false
  }
}

// Iniciar sesión
export async function signIn(formData: FormData) {
  const supabase = createServerSupabaseClient()
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    return { success: false, message: error.message }
  }

  // Verificar si es administrador
  const admin = await isAdmin()
  if (!admin) {
    await supabase.auth.signOut()
    return { success: false, message: "No tienes permisos de administrador" }
  }

  redirect("/admin")
}

// Cerrar sesión
export async function signOut() {
  const supabase = createServerSupabaseClient()
  await supabase.auth.signOut()
  redirect("/admin/login")
}
