"use server"

import { createServerSupabaseClient } from "./supabase"
import { revalidatePath } from "next/cache"

export async function seedInitialData() {
  const supabase = createServerSupabaseClient()

  // Verificar si ya existen datos en event_config
  const { data: existingConfig } = await supabase.from("event_config").select("id").limit(1)

  // Si no hay datos en event_config, insertar datos iniciales
  if (!existingConfig || existingConfig.length === 0) {
    // Insertar configuración del evento
    const { error: configError } = await supabase.from("event_config").insert({
      event_name: "Cicloturismo Termal de Federación – Segunda Edición",
      event_date: "2025-10-12",
      registration_limit: 300,
      registration_open: true,
      current_edition: 2,
    })

    if (configError) {
      console.error("Error al insertar configuración del evento:", configError)
      return { success: false, message: "Error al insertar configuración del evento" }
    }

    // Insertar imágenes del carrusel
    const { error: carouselError } = await supabase.from("carousel_images").insert([
      {
        image_url: "/placeholder.svg?height=1080&width=1920",
        alt_text: "Cicloturismo Termal - Imagen 1",
        display_order: 1,
      },
      {
        image_url: "/placeholder.svg?height=1080&width=1920",
        alt_text: "Cicloturismo Termal - Imagen 2",
        display_order: 2,
      },
    ])

    if (carouselError) {
      console.error("Error al insertar imágenes del carrusel:", carouselError)
    }

    // Insertar remera oficial
    const { error: jerseyError } = await supabase.from("official_jersey").insert({
      image_url: "/placeholder.svg?height=800&width=800",
      description:
        "<p>Remera oficial del evento Cicloturismo Termal de Federación – Segunda Edición.</p><p>Material de alta calidad, diseño exclusivo y confortable para la actividad.</p>",
    })

    if (jerseyError) {
      console.error("Error al insertar remera oficial:", jerseyError)
    }

    // Insertar beneficios
    const { error: benefitsError } = await supabase.from("benefits").insert([
      {
        title: "Jersey Oficial",
        description: "Remera exclusiva del evento",
        icon: "shirt",
        display_order: 1,
      },
      {
        title: "Buff",
        description: "Buff conmemorativo del evento",
        icon: "shirt",
        display_order: 2,
      },
      {
        title: "Kit de participante",
        description: "Kit completo con número y obsequios",
        icon: "award",
        display_order: 3,
      },
      {
        title: "Desayuno",
        description: "Desayuno antes de la partida",
        icon: "coffee",
        display_order: 4,
      },
      {
        title: "Hidratación",
        description: "Puestos de hidratación en el recorrido",
        icon: "droplet",
        display_order: 5,
      },
      {
        title: "Asistencia médica",
        description: "Equipo médico disponible durante todo el evento",
        icon: "heart",
        display_order: 6,
      },
      {
        title: "Seguro",
        description: "Seguro de accidentes para todos los participantes",
        icon: "shield",
        display_order: 7,
      },
      {
        title: "Asistencia técnica",
        description: "Soporte técnico para bicicletas durante el recorrido",
        icon: "wrench",
        display_order: 8,
      },
    ])

    if (benefitsError) {
      console.error("Error al insertar beneficios:", benefitsError)
    }

    // Insertar información de contacto
    const { error: contactError } = await supabase.from("contact_info").insert({
      show_map: true,
      map_latitude: -30.9795,
      map_longitude: -57.9304,
      map_zoom: 15,
    })

    if (contactError) {
      console.error("Error al insertar información de contacto:", contactError)
    }

    // Insertar redes sociales
    const { error: socialError } = await supabase.from("social_networks").insert([
      {
        name: "Instagram",
        url: "https://instagram.com",
        icon: "instagram",
        display_order: 1,
      },
      {
        name: "Facebook",
        url: "https://facebook.com",
        icon: "facebook",
        display_order: 2,
      },
      {
        name: "Email",
        url: "mailto:info@cicloturismo.com",
        icon: "mail",
        display_order: 3,
      },
    ])

    if (socialError) {
      console.error("Error al insertar redes sociales:", socialError)
    }

    // Insertar imágenes de galería de ejemplo
    const { error: galleryError } = await supabase.from("gallery_images").insert([
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+1",
        alt_text: "Cicloturismo Termal - Galería 1",
        display_order: 1,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+2",
        alt_text: "Cicloturismo Termal - Galería 2",
        display_order: 2,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+3",
        alt_text: "Cicloturismo Termal - Galería 3",
        display_order: 3,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+4",
        alt_text: "Cicloturismo Termal - Galería 4",
        display_order: 4,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+5",
        alt_text: "Cicloturismo Termal - Galería 5",
        display_order: 5,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+6",
        alt_text: "Cicloturismo Termal - Galería 6",
        display_order: 6,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+7",
        alt_text: "Cicloturismo Termal - Galería 7",
        display_order: 7,
      },
      {
        image_url: "/placeholder.svg?height=800&width=800&text=Imagen+8",
        alt_text: "Cicloturismo Termal - Galería 8",
        display_order: 8,
      },
    ])

    if (galleryError) {
      console.error("Error al insertar imágenes de galería:", galleryError)
    }

    revalidatePath("/")
    return { success: true, message: "Datos iniciales insertados correctamente" }
  }

  return { success: true, message: "Los datos ya existen" }
}

// Función para crear un usuario administrador por defecto
export async function createDefaultAdmin() {
  const supabase = createServerSupabaseClient()

  // Verificar si ya existe un administrador
  const { data: existingAdmins } = await supabase.from("admins").select("id").limit(1)

  if (!existingAdmins || existingAdmins.length === 0) {
    // Crear un usuario administrador por defecto
    const adminEmail = "admin@cicloturismo.com"
    const adminPassword = "admin123456"

    // Verificar si el usuario ya existe en la autenticación
    const { data: existingUser } = await supabase.auth.admin.getUserByEmail(adminEmail)

    if (!existingUser) {
      // Crear el usuario en la autenticación
      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email: adminEmail,
        password: adminPassword,
        email_confirm: true,
      })

      if (authError) {
        console.error("Error al crear usuario administrador:", authError)
        return { success: false, message: "Error al crear usuario administrador" }
      }

      // Insertar el usuario en la tabla de administradores
      const { error: adminError } = await supabase.from("admins").insert({
        email: adminEmail,
      })

      if (adminError) {
        console.error("Error al insertar administrador:", adminError)
        return { success: false, message: "Error al insertar administrador" }
      }

      return {
        success: true,
        message: "Usuario administrador creado correctamente",
        credentials: {
          email: adminEmail,
          password: adminPassword,
        },
      }
    } else {
      // El usuario ya existe en la autenticación, verificar si está en la tabla de administradores
      const { data: adminData } = await supabase.from("admins").select("*").eq("email", adminEmail).single()

      if (!adminData) {
        // Insertar el usuario en la tabla de administradores
        const { error: adminError } = await supabase.from("admins").insert({
          email: adminEmail,
        })

        if (adminError) {
          console.error("Error al insertar administrador:", adminError)
          return { success: false, message: "Error al insertar administrador" }
        }
      }

      return {
        success: true,
        message: "Usuario administrador ya existe",
        credentials: {
          email: adminEmail,
          password: "Ya configurada",
        },
      }
    }
  }

  return { success: true, message: "El administrador ya existe" }
}
