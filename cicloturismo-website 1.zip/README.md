# Cicloturismo Termal de Federación - Sitio Web

Este proyecto es un sitio web para el evento "Cicloturismo Termal de Federación – Segunda Edición", a realizarse el 12 de octubre de 2025 en Federación, Entre Ríos, Argentina.

## Tecnologías utilizadas

- **Frontend**: Next.js, React, Tailwind CSS
- **Autenticación**: Supabase Auth
- **Base de datos**: Supabase (PostgreSQL)
- **Hosting**: Vercel

## Características principales

- Página responsive y optimizada para móviles
- Carrusel de imágenes en el inicio
- Formulario de inscripción con validación
- Panel de administración para gestionar inscripciones y contenido
- Secciones editables: remera oficial, beneficios, galería, sponsors, contacto

## Configuración del proyecto

### Requisitos previos

- Node.js (versión 18 o superior)
- Cuenta en Vercel
- Cuenta en Supabase

### Configuración de Supabase

1. Crea un nuevo proyecto en Supabase
2. Ejecuta los scripts SQL para crear las tablas necesarias
3. Configura la autenticación en Supabase
4. Crea un bucket de almacenamiento llamado "cicloturismo"

### Variables de entorno

Crea un archivo `.env.local` con las siguientes variables:

\`\`\`
NEXT_PUBLIC_SUPABASE_URL=tu_url_de_supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_clave_anon_de_supabase
SUPABASE_SERVICE_ROLE_KEY=tu_clave_de_servicio_de_supabase
\`\`\`

### Instalación

1. Clona este repositorio
2. Instala las dependencias: `npm install`
3. Ejecuta el servidor de desarrollo: `npm run dev`
4. Abre [http://localhost:3000](http://localhost:3000) en tu navegador

### Despliegue en Vercel

1. Conecta tu repositorio a Vercel
2. Configura las variables de entorno en Vercel
3. Despliega la aplicación

## Estructura del proyecto

- `app/`: Páginas y rutas de la aplicación
- `components/`: Componentes reutilizables
- `lib/`: Utilidades, tipos y acciones del servidor
- `public/`: Archivos estáticos

## Panel de administración

El panel de administración permite:

- Ver todas las inscripciones
- Descargar datos como Excel o CSV
- Ver y gestionar comprobantes de pago
- Modificar cualquier sección del sitio
- Controlar visibilidad de secciones
- Reiniciar el sistema para una nueva edición

## Cómo crear una nueva edición del evento

1. Accede al panel de administración
2. Ve a la sección de configuración
3. Haz clic en "Nueva edición"
4. Actualiza la información del evento (fecha, remera, precio, etc.)
5. Guarda los cambios

## Cómo agregar más campos al formulario de inscripción

1. Modifica la tabla `registrations` en Supabase para agregar los nuevos campos
2. Actualiza el componente `RegistrationForm` para incluir los nuevos campos
3. Actualiza la función `createRegistration` en `lib/actions.ts` para procesar los nuevos campos

## Soporte

Si tienes alguna pregunta o problema, por favor crea un issue en este repositorio.
